function DegreesToRadians(degrees) {
  return (degrees * Math.PI / 180.0);
}

function RadiansToDegrees(radians) {
  return (radians * 180.0 / Math.PI);
}