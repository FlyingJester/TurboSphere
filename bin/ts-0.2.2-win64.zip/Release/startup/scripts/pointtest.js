Point(1,1,new Color(0,0,100,100));

function DrawScreen(){
FlipScreen();
}